import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Team } from '../../../models/Team';
import { TeamsService } from '../../../services/teams.service';
import { RouterModule } from '@angular/router';


@Component({
  selector: 'home',
  imports: [CommonModule, RouterModule],
  standalone: true,
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class AppComponent implements OnInit {
  title = 'Home';
  name = 'Nuno';
  teams: Team[] | null = null;

  constructor(private teamsSvc: TeamsService) { }

  ngOnInit(): void {
    this.teams = this.teamsSvc.getTeams();
  }
}
