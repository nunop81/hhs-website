export class Team {
    firstName = "";
    lastName: string = "";
    role: string = "";
}